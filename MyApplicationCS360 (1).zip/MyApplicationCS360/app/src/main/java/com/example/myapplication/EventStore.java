
package com.example.myapplication;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class EventStore {
    private static final String PREFS = "events_prefs";
    private static final String KEY_EVENTS = "events_list";

    public static void saveEvent(Context ctx, Event event) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY_EVENTS, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            arr.put(event.toJson());
            prefs.edit().putString(KEY_EVENTS, arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static List<Event> getEvents(Context ctx) {
        List<Event> out = new ArrayList<>();
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY_EVENTS, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                Event e = Event.fromJson(o);
                if (e != null) out.add(e);
            }
        } catch (Exception ignored) {}
        return out;
    }

    public static void clearAll(Context ctx) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_EVENTS).apply();
    }
}