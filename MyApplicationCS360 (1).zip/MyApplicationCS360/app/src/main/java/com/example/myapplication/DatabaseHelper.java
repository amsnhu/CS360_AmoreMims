package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "app.db";
    public static final int DB_VERSION = 3;
    public static final String T_USERS = "users";
    public static final String U_ID = "id";
    public static final String U_USERNAME = "username";
    public static final String U_PASSWORD = "password";
    public static final String T_EVENTS = "events";
    public static final String E_ID = "id";
    public static final String E_TITLE = "title";
    public static final String E_DATE = "date";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + T_USERS + " (" + U_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + U_USERNAME + " TEXT UNIQUE NOT NULL, " + U_PASSWORD + " TEXT NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + T_EVENTS + " (" + E_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + E_TITLE + " TEXT NOT NULL, " + E_DATE + " TEXT)");
        ContentValues cv = new ContentValues();
        cv.put(U_USERNAME, "demo");
        cv.put(U_PASSWORD, "demo123");
        db.insertWithOnConflict(T_USERS, null, cv, SQLiteDatabase.CONFLICT_IGNORE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + T_EVENTS);
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        onCreate(db);
    }

    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(T_USERS, new String[]{U_ID}, U_USERNAME + "=? AND " + U_PASSWORD + "=?", new String[]{username, password}, null, null, null);
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    public boolean createUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(U_USERNAME, username);
        cv.put(U_PASSWORD, password);
        long id = db.insertWithOnConflict(T_USERS, null, cv, SQLiteDatabase.CONFLICT_IGNORE);
        return id != -1;
    }
}