
package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;

public class EventsListActivity extends AppCompatActivity {
    private ListView listView;
    private Button newEventBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events_list);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        listView = findViewById(R.id.list_events);
        newEventBtn = findViewById(R.id.button_new_event);

        newEventBtn.setOnClickListener(v -> startActivity(new Intent(this, CreateEventActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        List<Event> events = EventStore.getEvents(this);
        List<String> display = new ArrayList<>();
        DateFormat df = DateFormat.getDateTimeInstance();
        for (Event e : events) {
            String s = e.getTitle() + " — " + df.format(e.getStartMillis());
            display.add(s);
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, display);
        listView.setAdapter(adapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}