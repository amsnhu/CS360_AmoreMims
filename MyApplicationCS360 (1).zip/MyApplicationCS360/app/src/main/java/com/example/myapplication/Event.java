
package com.example.myapplication;

import org.json.JSONException;
import org.json.JSONObject;

public class Event {
    private String title;
    private long startMillis;
    private long endMillis;

    public Event(String title, long startMillis, long endMillis) {
        this.title = title;
        this.startMillis = startMillis;
        this.endMillis = endMillis;
    }

    public String getTitle() { return title; }
    public long getStartMillis() { return startMillis; }
    public long getEndMillis() { return endMillis; }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("title", title);
            o.put("start", startMillis);
            o.put("end", endMillis);
        } catch (JSONException ignored) {}
        return o;
    }

    public static Event fromJson(JSONObject o) {
        try {
            return new Event(o.optString("title"),
                    o.optLong("start"),
                    o.optLong("end"));
        } catch (Exception e) {
            return null;
        }
    }
}