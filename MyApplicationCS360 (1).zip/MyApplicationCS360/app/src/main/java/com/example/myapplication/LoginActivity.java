package com.example.myapplication;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private static final String PREFS = "users_prefs";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";

    private EditText usernameEd;
    private EditText passwordEd;
    private Button loginBtn;
    private Button createAccountBtn;
    private Button sendSmsBtn;
    private Button createEventBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameEd = findViewById(R.id.edit_username);
        passwordEd = findViewById(R.id.edit_password);
        loginBtn = findViewById(R.id.button_login);
        createAccountBtn = findViewById(R.id.button_create_account);
        sendSmsBtn = findViewById(R.id.button_send_sms);
        createEventBtn = findViewById(R.id.button_create_event);

        loginBtn.setOnClickListener(v -> {
            String u = usernameEd.getText().toString().trim();
            String p = passwordEd.getText().toString().trim();
            if (u.isEmpty() || p.isEmpty()) {
                Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            String savedU = prefs.getString(KEY_USERNAME, null);
            String savedP = prefs.getString(KEY_PASSWORD, null);

            if (savedU == null) {
                Toast.makeText(this, "No account found. Please create one.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (u.equals(savedU) && p.equals(savedP)) {
                Toast.makeText(this, "Logged in as " + u, Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        });

        createAccountBtn.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));

        sendSmsBtn.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("smsto:")); // opens SMS app
            intent.putExtra("sms_body", "Hello from my app");
            try {
                startActivity(intent);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, "No SMS app available", Toast.LENGTH_SHORT).show();
            }
        });

        createEventBtn.setOnClickListener(v -> {
            // Open in-app events list (requires EventsListActivity in project)
            startActivity(new Intent(this, EventsListActivity.class));
        });
    }
}