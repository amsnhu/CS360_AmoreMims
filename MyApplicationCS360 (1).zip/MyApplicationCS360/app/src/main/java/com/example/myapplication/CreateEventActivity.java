
package com.example.myapplication;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CreateEventActivity extends AppCompatActivity {
    private EditText titleEd;
    private Button saveBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_event);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        titleEd = findViewById(R.id.edit_event_title);
        saveBtn = findViewById(R.id.button_save_event);

        saveBtn.setOnClickListener(v -> {
            String title = titleEd.getText().toString().trim();
            if (title.isEmpty()) {
                Toast.makeText(this, "Enter event title", Toast.LENGTH_SHORT).show();
                return;
            }
            long start = System.currentTimeMillis();
            long end = start + 60 * 60 * 1000; // default 1 hour
            Event e = new Event(title, start, end);
            EventStore.saveEvent(this, e);
            Toast.makeText(this, "Event saved", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}